#!/bin/bash
apt-get update
apt-get -y dist-upgrade
sleep 2
